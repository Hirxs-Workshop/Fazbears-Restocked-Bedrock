import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData, uiManager } from "@minecraft/server-ui";
import { dynamicToast, showCameraLoading } from "../utils.js";

class SecurityCameraSystem {
  constructor() {
    this.selections = {};
    this.connections = new Map();
    this.viewers = new Set();
    this.pendingExit = new Set();
    this.viewSessions = new Map();
    this.PC_EXIT_RADIUS = 8;
    this.PC_EXIT_RADIUS_SQUARED = 64;
    this.viewYaw = new Map();
    this.autoPan = new Map();
    this.cameraLocks = new Map();
    this.baseRotations = new Map();
    this.baseYaw = new Map();
    this.AUTO_PAN_SPEED = 0.8;
    this.AUTO_PAN_RANGE = 85;
    this.AUTO_PAN_DWELL_TICKS = 40;
    this.blockUpdateCounter = new Map();
    this.BLOCK_UPDATE_INTERVAL = 3;
    this.DEG_TO_RAD = Math.PI / 180;
    this.tickInterval = null;
    this.cleanupInterval = null;
  }

  async getWorldTimeLabelsAsync(player) {
    let day;
    let daytime;
    try {
      if (typeof world.getTimeOfDay === 'function') {
        try { daytime = world.getTimeOfDay(player.dimension); } catch {}
        if (daytime === undefined) daytime = world.getTimeOfDay();
      }
    } catch {}
    try {
      if (typeof world.getDay === 'function') {
        try { day = world.getDay(player.dimension); } catch {}
        if (day === undefined) day = world.getDay();
      }
    } catch {}
    try {
      if (day === undefined) {
        const res = player.runCommand?.("time query day");
        const msg = res?.statusMessage ?? res?.statusText ?? res?.message;
        const n = this.extractNumber(msg);
        if (typeof n === 'number') day = n;
      }
    } catch {}
    try {
      if (daytime === undefined) {
        const res = player.runCommand?.("time query daytime");
        const msg = res?.statusMessage ?? res?.statusText ?? res?.message;
        const n = this.extractNumber(msg);
        if (typeof n === 'number') daytime = n;
      }
    } catch {}
    try {
      if (day === undefined && player.runCommandAsync) {
        const res = await player.runCommandAsync("time query day");
        const msg = res?.statusMessage ?? res?.statusText ?? res?.message;
        const n = this.extractNumber(msg);
        if (typeof n === 'number') day = n;
      }
    } catch {}
    try {
      if (daytime === undefined && player.runCommandAsync) {
        const res = await player.runCommandAsync("time query daytime");
        const msg = res?.statusMessage ?? res?.statusText ?? res?.message;
        const n = this.extractNumber(msg);
        if (typeof n === 'number') daytime = n;
      }
    } catch {}
    if (daytime === undefined) daytime = 0;
    if (day === undefined) day = 0;
    return {
      period: this.formatPeriod(daytime, day),
      clock: this.formatClock(daytime),
    };
  }

  extractNumber(text) {
    try {
      if (!text) return undefined;
      const m = String(text).match(/-?\d+/);
      if (!m) return undefined;
      return Number(m[0]);
    } catch { return undefined; }
  }

  formatPeriod(daytime, day) {
    try {
      const hour24 = Math.floor(((daytime % 24000) / 1000 + 6) % 24);
      const isDay = hour24 >= 6 && hour24 < 18;
      const label = isDay ? "Day" : "Night";
      const dayIndex = (day ?? 0) + 1;
      return `${label} ${dayIndex}`;
    } catch { return ""; }
  }

  formatClock(daytime) {
    try {
      const hour24 = Math.floor(((daytime % 24000) / 1000 + 6) % 24);
      let h = hour24 % 12; if (h === 0) h = 12;
      const ampm = hour24 < 12 ? " AM" : " PM";
      return `${h}${ampm}`;
    } catch { return ""; }
  }

  initialize() {
    world.afterEvents.playerInteractWithBlock.subscribe((event) => this.onBlockInteract(event));
    world.afterEvents.pistonActivate.subscribe((event) => this.onPistonActivate(event));
    system.run(() => this.loadConnections());
  }

  startCameraIntervals() {
    if (this.tickInterval !== null) return;
    this.tickInterval = system.runInterval(() => {
      if (this.viewers.size === 0) {
        this.stopCameraIntervals();
        return;
      }
      this.tickExitByCrouch();
    }, 1);
    
    if (this.cleanupInterval === null) {
      this.cleanupInterval = system.runInterval(() => {
        if (this.viewers.size === 0 && this.cameraLocks.size === 0) {
          if (this.cleanupInterval !== null) {
            system.clearRun(this.cleanupInterval);
            this.cleanupInterval = null;
          }
          return;
        }
        this.cleanupOrphanedLocks();
      }, 100);
    }
  }

  stopCameraIntervals() {
    if (this.tickInterval !== null) {
      system.clearRun(this.tickInterval);
      this.tickInterval = null;
    }
  }

  ensureCameraIntervals() {
    if (this.viewers.size > 0) {
      this.startCameraIntervals();
    }
  }

  cleanupOrphanedLocks() {
    try {
      if (this.cameraLocks.size === 0 && this.viewers.size === 0) return;
      
      const activePlayers = new Set(world.getPlayers().map(p => p.id));
      
      for (const [camPos, playerId] of this.cameraLocks.entries()) {
        if (!activePlayers.has(playerId)) {
          this.cameraLocks.delete(camPos);
        } else {
          const session = this.viewSessions.get(playerId);
          const isValid = session && session.cam === camPos && this.viewers.has(playerId);
          if (!isValid) {
            this.cameraLocks.delete(camPos);
          }
        }
      }
      
      for (const playerId of this.viewers) {
        if (!activePlayers.has(playerId)) {
          const session = this.viewSessions.get(playerId);
          const initialRotation = this.baseRotations.get(playerId);
          if (session && session.cam && initialRotation !== undefined) {
            try {
              const dimension = world.getDimension(session.dim);
              const camBlock = this.blockFromLocStr(dimension, session.cam);
              if (camBlock && camBlock.typeId === "fr:security_cameras") {
                const currentRotation = camBlock.permutation.getState("fr:rotation");
                if (currentRotation !== initialRotation) {
                  const newPerm = camBlock.permutation.withState("fr:rotation", initialRotation);
                  camBlock.setPermutation(newPerm);
                }
              }
            } catch {}
          }
          
          this.viewers.delete(playerId);
          this.viewSessions.delete(playerId);
          this.viewYaw.delete(playerId);
          this.autoPan.delete(playerId);
          this.baseRotations.delete(playerId);
          this.baseYaw.delete(playerId);
          this.blockUpdateCounter.delete(playerId);
        }
      }
    } catch {}
  }

  onBlockInteract(event) {
    const { player, block, itemStack } = event;
    if (!player || !block) return;

    const blockId = block.typeId;
    const itemId = itemStack?.typeId;

    if (blockId === "fr:security_cameras") {
      if (itemId === "fr:faz-diver_security") {
        this.selectCamera(player, block);
      }
      return;
    }

    if (blockId === "fr:old_pc" || blockId === "fr:black_old_pc") {
      if (itemId === "fr:faz-diver_security") {
        this.connectPcToSelectedCamera(player, block);
        return;
      }

      this.viewThroughLinkedCamera(player, block);
      return;
    }
  }

  onPistonActivate(event) {
    try {
      const { piston, isExpanding } = event;
      if (!piston || !isExpanding) return;

      let attachedLocations = [];
      try {
        attachedLocations = piston.getAttachedBlocksLocations();
      } catch (e) {
        try {
          const blocks = piston.getAttachedBlocks();
          attachedLocations = blocks.map(b => b.location);
        } catch {}
      }

      if (!attachedLocations || attachedLocations.length === 0) return;

      const pistonBlock = piston.block;
      if (!pistonBlock) return;
      const dimension = pistonBlock.dimension;

      for (const loc of attachedLocations) {
        try {
          const block = dimension.getBlock(loc);
          if (!block || block.typeId !== "fr:security_cameras") continue;

          const camPosStr = this.locStr({ x: Math.floor(loc.x), y: Math.floor(loc.y), z: Math.floor(loc.z) });

          for (const [playerId, session] of this.viewSessions.entries()) {
            if (session.cam === camPosStr) {
              const player = world.getPlayers().find(p => p.id === playerId);
              if (player) {
                try {
                  const list = this.connections.get(session.pc) ?? [];
                  const idxInList = list.indexOf(camPosStr);
                  if (idxInList > -1) list.splice(idxInList, 1);
                  this.connections.set(session.pc, list);
                  this.saveConnections();

                  if (list.length > 0) {
                    this.autoPan.set(playerId, { offset: 0, dir: 1, dwell: 0 });
                    this.baseRotations.delete(playerId);
                    this.baseYaw.delete(playerId);
                    try { this.cameraLocks.delete(session.cam); } catch {}
                    try { uiManager.closeAllForms(player); } catch {}
                    const nextIdx = Math.min(Math.max(idxInList, 0), list.length - 1);
                    const nextCam = list[nextIdx] ?? list[0];
                    this.viewYaw.set(player.id, 0);
                    this.applyView(player, dimension, nextCam, session.pc);
                  } else {
                    this.exitViewDueToCameraMovement(player, camPosStr);
                  }
                } catch {
                  this.exitViewDueToCameraMovement(player, camPosStr);
                }
              }
            }
          }

          system.runTimeout(() => {
            for (const [pcPosStr, camList] of this.connections.entries()) {
              const index = camList.indexOf(camPosStr);
              if (index > -1) {
                camList.splice(index, 1);
                this.connections.set(pcPosStr, camList);
              }
            }
            this.saveConnections();
          }, 10);
        } catch {}
      }
    } catch {}
  }

  selectCamera(player, block) {
    const pos = this.posOf(block);
    this.selections[player.id] = {
      pos,
      type: "camera",
    };

    player.sendMessage(
      dynamicToast(
        "§l§aCAMERA SELECTED",
        `§qID: §f§ffr:security_cameras\n§qPos: §f${pos.x}, ${pos.y}, ${pos.z}`,
        "textures/fr_ui/approve_icon",
        "textures/fr_ui/approve_ui"
      )
    );
  }

  connectPcToSelectedCamera(player, pcBlock) {
    const sel = this.selections[player.id];
    if (!sel || sel.type !== "camera") {
      player.sendMessage(
        dynamicToast(
          "§l§cERROR",
          "§cSelect a camera first with the faz-diver (security)",
          "textures/fr_ui/error_icon",
          "textures/fr_ui/error_ui"
        )
      );
      return;
    }

    const cameraPosStr = this.locStr(sel.pos);
    const pcPosStr = this.locStr(this.posOf(pcBlock));

    const list = this.connections.get(pcPosStr) ?? [];
    if (!list.includes(cameraPosStr)) list.push(cameraPosStr);
    this.connections.set(pcPosStr, list);
    this.saveConnections();

    delete this.selections[player.id];

    player.sendMessage(
      dynamicToast(
        "§l§eLINKED",
        `§6PC: §f${pcPosStr}\n§6Camera: §f${cameraPosStr}`,
        "textures/fr_ui/unlinked_icon",
        "textures/fr_ui/unlinked_ui"
      )
    );
  }

  showLockedPcUI(player, pcBlock) {
    try {
      const showLockedForm = () => {
        try { player.runCommand(`hud @s hide all`); } catch {}
        
        const form = new ActionFormData()
          .title("§r§f§l§p§c")
          .body("");

        form.label("tx:welcome_textures/fr_ui/welcome_text_terminal");
        form.label("tx:hero_textures/fr_ui/fr_info_img");
        form.label("tx:banner_textures/fr_ui/system_badge");
        
        form.label("sys:name_§0Fazbear-OS");
        form.label("sys:build_§0First edition");
        form.label("sys:ver_§01.21.110 A");
        
        form.label("reg:name_§0PlayerName");
        form.label("reg:id_§000 0-000-000");
        
        form.label(`pc:cpu_§0GenuineIntel`);
        form.label("pc:model_§0Pentium(R) II");
        form.label("pc:ram_§064.00MB RAM");
        
        form.label("cr:sub_");
        form.label(`cr:txt_§0§lHead Director§r§0
- Polarfrederick

§lAssistant Director§r§0
- Kristoffer1976

§lMain Developer§r§0
- Hyrxs

§lConcept art§r§0
- Electro1987
- Guipcbonnie

§lMusic/Sound Designer§r§0
- Werty_is_me
- Foxlyticalxd

§lAnimator§r§0
- M.forbidden.
- Kiandraomg

§lCoders§r§0
- Sgtsarnt3
- Warden45._31258

§lTexture designer§r§0
- Mansam47
- Kilokegor
- Guipcbonnie
- Foxisgaming_
- Firecaptain221
- Polarfrederick
- Hyrxs
- Kristoffer1976

§lBlock Modeler§r§0
- Mansam47
- Kilokegor
- Guipcbonnie
- Foxisgaming_
- Firecaptain221
- Polarfrederick
- Hyrxs
- Kristoffer1976





`);

        this.getWorldTimeLabelsAsync(player).then((labels) => {
          try { 
            form.label(`dock:right3_§l${labels.clock}\n§r${labels.period}`);
            form.label("dock:right2_§lFaz-diver:\n§rNo found!");
            form.label(`dock:right_§lUser:\n§r${player?.nameTag ?? player?.name ?? "Player"}`); 
          } catch {}
          return form.show(player);
        }).catch(() => {
          try { form.label("dock:right_"); } catch {}
          return form.show(player);
        }).then((res) => {
          this.resetPlayerCamera(player);
        }).catch(() => {
          this.resetPlayerCamera(player);
        });
      };

      try { player.runCommand(`camera @s fov_set 30`); } catch {}
      const animated = this.animatePcApproach(player, pcBlock);
      if (animated) {
        system.runTimeout(() => showLockedForm(), 40);
      } else {
        showLockedForm();
      }
    } catch {
      this.resetPlayerCamera(player);
    }
  }

  viewThroughLinkedCamera(player, pcBlock) {
    try {
      const pcPosStr = this.locStr(this.posOf(pcBlock));
      let camList = this.connections.get(pcPosStr);
      
      if (camList && camList.length > 0) {
        const validCameras = [];
        for (const camPosStr of camList) {
          const camBlock = this.blockFromLocStr(pcBlock.dimension, camPosStr);
          if (camBlock && camBlock.typeId === "fr:security_cameras") {
            validCameras.push(camPosStr);
          }
        }
        
        if (validCameras.length !== camList.length) {
          this.connections.set(pcPosStr, validCameras);
          this.saveConnections();
          camList = validCameras;
        }
      }
      
      if (!camList || camList.length === 0) {
        this.showLockedPcUI(player, pcBlock);
        return;
      }

      const showMainForm = () => {
        try { player.runCommand(`hud @s hide all`); } catch {}
        
        const form = new ActionFormData().title("§O§L§D§P§C").body("§7Open the primary camera or manage links");
form.button("bt:b_Open camera", "textures/fr_ui/security_camera_icon");
form.button("bt:g_Manage cameras", "textures/fr_ui/gear");

form.label("tx:welcome_textures/fr_ui/welcome_text_terminal");

form.label("tx:hero_textures/fr_ui/fr_info_img");
form.label("tx:banner_textures/fr_ui/system_badge");

form.label("sys:name_§0Fazbear-OS");
form.label("sys:build_§0First edition");
form.label("sys:ver_§01.21.110 A");

form.label("reg:name_§0PlayerName");
form.label("reg:id_§0000-000-000");

form.label(`pc:cpu_§0GenuineIntel`);
form.label("pc:model_§0Pentium(R) II");
form.label("pc:ram_§064.00MB RAM");

form.label("cr:sub_");
form.label(`cr:txt_§0§lHead Director§r§0
- Polarfrederick

§lAssistant Director§r§0
- Kristoffer1976

§lMain Developer§r§0
- Hyrxs

§lConcept art§r§0
- Electro1987
- Guipcbonnie

§lMusic/Sound Designer§r§0
- Werty_is_me
- Foxlyticalxd

§lAnimator§r§0
- M.forbidden.
- Kiandraomg

§lCoders§r§0
- Sgtsarnt3
- Warden45._31258

§lTexture designer§r§0
- Mansam47
- Kilokegor
- Guipcbonnie
- Foxisgaming_
- Firecaptain221
- Polarfrederick
- Hyrxs
- Kristoffer1976

§lBlock Modeler§r§0
- Mansam47
- Kilokegor
- Guipcbonnie
- Foxisgaming_
- Firecaptain221
- Polarfrederick
- Hyrxs
- Kristoffer1976






`);
  this.getWorldTimeLabelsAsync(player).then((labels) => {
          try { form.label(`dock:right3_§l${labels.clock}\n§r${labels.period}`);
form.label("dock:right2_§lFaz-diver:\n§rNo found!");
form.label(`dock:right_§lUser:\n§r${player?.nameTag ?? player?.name ?? "Player"}`); } catch {}
          return form.show(player);
        }).catch(() => {
          try { form.label("dock:right_"); } catch {}
          return form.show(player);
        }).then((res) => {
          if (res.canceled) { this.resetPlayerCamera(player); return; }
          const idx = res.selection;
          if (idx === undefined) { this.resetPlayerCamera(player); return; }
          if (idx === 0) {
            const target = camList[0];
            if (!target) { this.resetPlayerCamera(player); return; }
            
            showCameraLoading(player);
            
            system.runTimeout(() => {
              this.viewYaw.set(player.id, 0);
              this.applyView(player, pcBlock.dimension, target, pcPosStr);
            }, 0);
            
            return;
          }
          if (idx === 1) {
            this.resetPlayerCamera(player);
            this.manageCameras(player, pcBlock);
            return;
          }
          this.resetPlayerCamera(player);
        }).catch(() => {});
      };

      try { player.runCommand(`camera @s fov_set 30`); } catch {}
      const animated = this.animatePcApproach(player, pcBlock);
      if (animated) {
        system.runTimeout(() => showMainForm(), 40);
      } else {
        showMainForm();
      }
    } catch {}
  }

  applyView(player, dimension, camPosStr, pcPosStr) {
    const camBlock = this.blockFromLocStr(dimension, camPosStr);
    if (!camBlock || camBlock.typeId !== "fr:security_cameras") {
      const camList = this.connections.get(pcPosStr) ?? [];
      const index = camList.indexOf(camPosStr);
      if (index > -1) {
        camList.splice(index, 1);
        this.connections.set(pcPosStr, camList);
        this.saveConnections();
      }
      
      if (camList.length > 0) {
        this.viewYaw.set(player.id, 0);
        system.run(() => this.applyView(player, dimension, camList[0], pcPosStr));
      } else {
        const pcBlock = this.blockFromLocStr(dimension, pcPosStr);
        if (pcBlock) {
          this.showLockedPcUI(player, pcBlock);
        }
      }
      return;
    }

    const lockOwner = this.cameraLocks.get(camPosStr);
    if (lockOwner && lockOwner !== player.id) {
      const ownerSession = this.viewSessions.get(lockOwner);
      const isValidLock = ownerSession && ownerSession.cam === camPosStr && this.viewers.has(lockOwner);
      
      if (!isValidLock) {
        this.cameraLocks.delete(camPosStr);
      } else {
        const ownerPlayer = world.getPlayers().find(p => p.id === lockOwner);
        if (!ownerPlayer) {
          this.cameraLocks.delete(camPosStr);
        } else {
          try { player.runCommand(`camera @s clear`); } catch {}
          try { player.runCommand(`camera @s fade time 0 0 0`); } catch {}
          try { player.runCommand(`camera @s fov_reset`); } catch {}
          try { player.runCommand(`hud @s reset`); } catch {}
          
          player.sendMessage(
            dynamicToast(
              "§l§cCAMERA IN USE",
              "§7This camera is being used by another player",
              "textures/fr_ui/deny_icon",
              "textures/fr_ui/deny_ui"
            )
          );
          return;
        }
      }
    }

    const initialRotation = camBlock.permutation.getState("fr:rotation");
    const basePose = this.frontPoseOf(camBlock);
    const pid = player.id;
    
    const alreadyViewing = this.viewers.has(pid);
    if (alreadyViewing) {
      this.viewYaw.set(pid, 0);
    }

    const finish = () => {
      try { player.runCommand(`camera @s clear`); } catch {}
      try { player.runCommand(`hud @s hide all`); } catch {}

      const yawOffset = this.viewYaw.get(pid) ?? 0;
      const pos = basePose.pos;
      const yaw = basePose.yaw + yawOffset;
      const pitch = basePose.pitch;

      const applied = this.trySetCamera(player, pos, yaw, pitch);
      if (!applied) {
        try { uiManager.closeAllForms(player); } catch {}
        
        try { player.runCommand(`camera @s clear`); } catch {}
        try { player.runCommand(`camera @s fade time 0 0 0`); } catch {}
        try { player.runCommand(`camera @s fov_reset`); } catch {}
        try { player.runCommand(`hud @s reset`); } catch {}
        
        player.sendMessage(
          dynamicToast(
            "§l§cCAMERA ERROR",
            "§7Could not activate the camera with the current command version",
            "textures/fr_ui/error_icon",
            "textures/fr_ui/error_ui"
          )
        );
        return;
      }
      try { player.runCommand(`camera @s set ease 0.05`); } catch {}
      this.viewers.add(player.id);
      this.ensureCameraIntervals();
      try { this.viewSessions.set(player.id, { pc: pcPosStr, dim: dimension.id, cam: camPosStr }); } catch {}
      this.autoPan.set(player.id, { offset: 0, dir: 1, dwell: 0 });
      this.baseRotations.set(player.id, initialRotation);
      this.baseYaw.set(player.id, basePose.yaw);
      this.cameraLocks.set(camPosStr, player.id);
      this.applyControlOverlay(player, pcPosStr, camPosStr, dimension);
    };

    if (alreadyViewing) {
      try { player.runCommand(`camera @s fade time 0.4 0.4 0.4 color 0 0 0`); } catch {}
      system.runTimeout(() => finish(), 5);
      return;
    }

    system.runTimeout(() => {
      try { player.runCommand(`camera @s fade time 0.4 0.4 0.4 color 0 0 0`); } catch {}
      system.runTimeout(() => finish(), 5);
    }, 25);
  }

  tickExitByCrouch() {
    try {
      for (const player of world.getPlayers()) {
        const pid = player.id;
        if (!this.viewers.has(pid)) continue;

        if (player.isSneaking) {
          this.exitView(player);
          continue;
        }

        const session = this.viewSessions.get(pid);
        if (!session) continue;
        const [px, py, pz] = session.pc.split(',').map(Number);
        const dx = player.location.x - px - 0.5;
        const dy = player.location.y - py - 0.5;
        const dz = player.location.z - pz - 0.5;
        if (dx * dx + dy * dy + dz * dz > this.PC_EXIT_RADIUS_SQUARED) {
          this.exitView(player);
          continue;
        }

        try {
          const sess = this.viewSessions.get(pid);
          if (!sess) continue;
          const dim = player.dimension;
          const camBlock = this.blockFromLocStr(dim, sess.cam ?? "");
          if (!camBlock || camBlock.typeId !== "fr:security_cameras") {
            const camList = this.connections.get(sess.pc) ?? [];
            const oldIdx = camList.indexOf(sess.cam);
            if (oldIdx > -1) camList.splice(oldIdx, 1);
            this.connections.set(sess.pc, camList);
            this.saveConnections();

            if (camList.length > 0) {
              this.autoPan.set(pid, { offset: 0, dir: 1, dwell: 0 });
              this.baseRotations.delete(pid);
              this.baseYaw.delete(pid);
              try { this.cameraLocks.delete(sess.cam); } catch {}
              try { uiManager.closeAllForms(player); } catch {}
              const nextIdx = Math.min(Math.max(oldIdx, 0), camList.length - 1);
              const nextCam = camList[nextIdx] ?? camList[0];
              this.viewYaw.set(pid, 0);
              try { this.applyView(player, world.getDimension(sess.dim), nextCam, sess.pc); } catch { this.applyView(player, dim, nextCam, sess.pc); }
            } else {
              this.exitViewDueToCameraMovement(player, sess.cam);
            }
            continue;
          }
          
          const baseYawValue = this.baseYaw.get(pid);
          if (baseYawValue === undefined) continue;
          
          const manualYawOffset = this.viewYaw.get(pid) ?? 0;
          if (manualYawOffset !== 0) continue;
          
          const camLoc = camBlock.location;
          const centerX = camLoc.x + 0.5;
          const centerY = camLoc.y + 0.6;
          const centerZ = camLoc.z + 0.5;
          const offsetDist = 0.4;
          
          const speed = this.AUTO_PAN_SPEED;
          const half = this.AUTO_PAN_RANGE * 0.5;
          const st = this.autoPan.get(pid) ?? { offset: 0, dir: 1, dwell: 0 };
          if (st.dwell && st.dwell > 0) {
            st.dwell -= 1;
            this.autoPan.set(pid, st);
            const yawHold = baseYawValue + st.offset;
            
            const yawRadDwell = yawHold * this.DEG_TO_RAD;
            const sinDwell = Math.sin(yawRadDwell);
            const cosDwell = Math.cos(yawRadDwell);
            const dwellPos = {
              x: centerX - sinDwell * offsetDist,
              y: centerY,
              z: centerZ + cosDwell * offsetDist
            };
            
            this.trySetCamera(player, dwellPos, yawHold, 0);
            this.updateCameraBlockRotationThrottled(pid, dim, sess.cam, yawHold);
            continue;
          }
          let next = st.offset + st.dir * speed;
          let dirn = st.dir;
          let dwell = 0;
          if (next > half) { next = half; dirn = -1; dwell = this.AUTO_PAN_DWELL_TICKS; }
          if (next < -half) { next = -half; dirn = 1; dwell = this.AUTO_PAN_DWELL_TICKS; }
          this.autoPan.set(pid, { offset: next, dir: dirn, dwell });
          const yaw = baseYawValue + next;
          
          const yawRadAdvance = yaw * this.DEG_TO_RAD;
          const sinAdvance = Math.sin(yawRadAdvance);
          const cosAdvance = Math.cos(yawRadAdvance);
          const advancePos = {
            x: centerX - sinAdvance * offsetDist,
            y: centerY,
            z: centerZ + cosAdvance * offsetDist
          };
          
          this.trySetCamera(player, advancePos, yaw, 0);
          this.updateCameraBlockRotationThrottled(pid, dim, sess.cam, yaw);
        } catch {}
      }
    } catch {}
  }

  exitView(player) {
    try {
      const pid = player.id;
      if (this.pendingExit.has(pid)) return;
      this.pendingExit.add(pid);
      this.viewers.delete(pid);
      const session = this.viewSessions.get(pid);
      if (session && session.cam) {
        const initialRotation = this.baseRotations.get(pid);
        if (initialRotation !== undefined) {
          try {
            const dimension = world.getDimension(session.dim);
            const camBlock = this.blockFromLocStr(dimension, session.cam);
            if (camBlock && camBlock.typeId === "fr:security_cameras") {
              const currentRotation = camBlock.permutation.getState("fr:rotation");
              if (currentRotation !== initialRotation) {
                const newPerm = camBlock.permutation.withState("fr:rotation", initialRotation);
                camBlock.setPermutation(newPerm);
              }
            }
          } catch {}
        }
        this.cameraLocks.delete(session.cam);
      }
      this.viewSessions.delete(pid);
      this.viewYaw.delete(pid);
      this.autoPan.delete(pid);
      this.baseRotations.delete(pid);
      this.baseYaw.delete(pid);
      this.blockUpdateCounter.delete(pid);
      
      try { uiManager.closeAllForms(player); } catch {}
      
      try { player.runCommand(`camera @s fade time 0.5 1 0.5 color 0 0 0`); } catch {}
      system.runTimeout(() => {
        try { player.runCommand(`camera @s clear`); } catch {}
        try { player.runCommand(`camera @s fov_reset`); } catch {}
        try { player.runCommand(`hud @s reset`); } catch {}
        try {
        } catch {}
        this.pendingExit.delete(pid);
      }, 20);
    } catch {}
  }

  exitViewDueToCameraMovement(player, camPosStr) {
    try {
      const pid = player.id;
      if (this.pendingExit.has(pid)) return;
      this.pendingExit.add(pid);
      
      this.viewers.delete(pid);
      const session = this.viewSessions.get(pid);
      
      if (session && session.cam) {
        this.cameraLocks.delete(session.cam);
      }
      
      this.viewSessions.delete(pid);
      this.viewYaw.delete(pid);
      this.autoPan.delete(pid);
      this.baseRotations.delete(pid);
      this.baseYaw.delete(pid);
      this.blockUpdateCounter.delete(pid);
      
      try { uiManager.closeAllForms(player); } catch {}
      
      try { player.runCommand(`camera @s clear`); } catch {}
      try { player.runCommand(`camera @s fade time 0 0 0`); } catch {}
      try { player.runCommand(`camera @s fov_reset`); } catch {}
      try { player.runCommand(`hud @s reset`); } catch {}
      
      this.pendingExit.delete(pid);
      
      player.sendMessage(
        dynamicToast(
          "§l§pCAMERA DISCONNECTED",
          "§7The camera was moved or destroyed",
          "textures/fr_ui/warning_icon",
          "textures/fr_ui/warning_ui"
        )
      );
    } catch {}
  }

  yawToRotationIndex(yaw) {
    const angles = [180, 200, 225, 250, 270, 290, 315, 335, 0, 25, 45, 70, 90, 115, 135, 160];
    
    let normalizedYaw = yaw % 360;
    if (normalizedYaw < 0) normalizedYaw += 360;
    
    let closestIndex = 0;
    let minDiff = 360;
    
    for (let i = 0; i < angles.length; i++) {
      let diff = Math.abs(normalizedYaw - angles[i]);
      if (diff > 180) diff = 360 - diff;
      
      if (diff < minDiff) {
        minDiff = diff;
        closestIndex = i;
      }
    }
    
    return closestIndex;
  }

  updateCameraBlockRotation(dimension, camPosStr, currentYaw) {
    try {
      const camBlock = this.blockFromLocStr(dimension, camPosStr);
      if (!camBlock || camBlock.typeId !== "fr:security_cameras") return;
      
      const rotationIndex = this.yawToRotationIndex(currentYaw);
      const currentRotation = camBlock.permutation.getState("fr:rotation");
      
      if (currentRotation !== rotationIndex) {
        const newPerm = camBlock.permutation.withState("fr:rotation", rotationIndex);
        camBlock.setPermutation(newPerm);
      }
    } catch (e) {}
  }

  updateCameraBlockRotationThrottled(playerId, dimension, camPosStr, currentYaw) {
    const counter = this.blockUpdateCounter.get(playerId) ?? 0;
    if (counter >= this.BLOCK_UPDATE_INTERVAL) {
      this.updateCameraBlockRotation(dimension, camPosStr, currentYaw);
      this.blockUpdateCounter.set(playerId, 0);
    } else {
      this.blockUpdateCounter.set(playerId, counter + 1);
    }
  }

  posOf(block) {
    const l = block.location;
    return { x: Math.floor(l.x), y: Math.floor(l.y), z: Math.floor(l.z) };
  }

  locStr(pos) {
    return `${pos.x},${pos.y},${pos.z}`;
  }

  blockFromLocStr(dimension, locStr) {
    const [x, y, z] = locStr.split(",").map(Number);
    return dimension.getBlock({ x, y, z });
  }

  frontPoseOf(block) {
    const loc = block.location;
    const centerX = loc.x + 0.5;
    const centerY = loc.y + 0.6;
    const centerZ = loc.z + 0.5;
    let yaw = 180;
    
    try {
      const rotation = block.permutation.getState("fr:rotation");
      if (rotation !== undefined && rotation !== null) {
        const angles = [180, 200, 225, 250, 270, 290, 315, 335, 0, 25, 45, 70, 90, 115, 135, 160];
        yaw = (rotation >= 0 && rotation < angles.length) ? angles[rotation] : 180;
      }
    } catch {}
    
    const yawRad = yaw * this.DEG_TO_RAD;
    const sinYaw = Math.sin(yawRad);
    const cosYaw = Math.cos(yawRad);
    
    const offsetDist = 0.4;
    const pos = { 
      x: centerX - sinYaw * offsetDist, 
      y: centerY, 
      z: centerZ + cosYaw * offsetDist 
    };
    return { pos, yaw, pitch: 0 };
  }

  pcApproachPoseOf(block) {
    try {
      if (!block) return undefined;
      const center = { x: block.location.x + 0.5, y: block.location.y + 0.75, z: block.location.z + 0.5 };
      let dir = { x: 0, z: 1 };
      try {
        const face = block.permutation.getState("minecraft:cardinal_direction");
        if (face === "north") dir = { x: 0, z: -1 };
        else if (face === "south") dir = { x: 0, z: 1 };
        else if (face === "east") dir = { x: 1, z: 0 };
        else if (face === "west") dir = { x: -1, z: 0 };
      } catch {}
      const distance = 1.2;
      const pos = {
        x: center.x - (dir.x ?? 0) * distance,
        y: center.y - 0.034,
        z: center.z - (dir.z ?? 0) * distance,
      };
      const dx = center.x - pos.x;
      const dy = center.y - pos.y;
      const dz = center.z - pos.z;
      const len = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (!len) return undefined;
      const norm = { x: dx / len, y: dy / len, z: dz / len };
      const yaw = this.vectorToYaw(norm);
      const pitch = this.vectorToPitch(norm);
      return { pos, yaw, pitch };
    } catch { return undefined; }
  }

  animatePcApproach(player, pcBlock) {
    try {
      const pose = this.pcApproachPoseOf(pcBlock);
      if (!pose) return false;
      return this.tryAnimateCamera(player, pose.pos, pose.yaw, pose.pitch, 2, "in_out_cubic");
    } catch { return false; }
  }

  vectorToYaw(dir) {
    try {
      const yawRad = Math.atan2(-dir.x, dir.z);
      let yawDeg = yawRad * 180 / Math.PI;
      if (yawDeg < 0) yawDeg += 360;
      return yawDeg;
    } catch { return 180; }
  }

  vectorToPitch(dir) {
    try {
      const pitchRad = Math.asin(Math.max(-1, Math.min(1, dir.y)));
      const pitchDeg = pitchRad * 180 / Math.PI;
      return pitchDeg;
    } catch { return 0; }
  }

  transformCameraRotation(yaw, pitch) {
    return { yaw, pitch };
  }

  tryAnimateCamera(player, pos, yaw, pitch, duration, easing) {
    let applied = false;
    try {
      const rotated = this.transformCameraRotation(yaw, pitch);
      const x = pos.x.toFixed(3), y = pos.y.toFixed(3), z = pos.z.toFixed(3);
      const yawStr = rotated.yaw.toFixed(1), pitchStr = rotated.pitch.toFixed(1);
      const durationStr = String(duration ?? 0);
      const easeStr = easing ?? "in_out_cubic";
      const variants = [
        `camera @s set minecraft:free ease ${durationStr} ${easeStr} pos ${x} ${y} ${z} rot ${pitchStr} ${yawStr}`,
        `camera @s set minecraft:free ease ${durationStr} ${easeStr} pos ${x} ${y} ${z} rot ${yawStr} ${pitchStr}`,
        `camera @s set minecraft:free ease ${durationStr} ${easeStr} position ${x} ${y} ${z} rotation ${yawStr} ${pitchStr}`,
        `camera @s set free ease ${durationStr} ${easeStr} pos ${x} ${y} ${z} rot ${yawStr} ${pitchStr}`,
      ];
      for (const cmd of variants) {
        if (applied) break;
        try { player.runCommand(cmd); applied = true; } catch {}
      }
    } catch {}
    return applied;
  }

  trySetCamera(player, pos, yaw, pitch) {
    let applied = false;
    try {
      const rotated = this.transformCameraRotation(yaw, pitch);
      const x = pos.x.toFixed(3), y = pos.y.toFixed(3), z = pos.z.toFixed(3);
      const yawStr = rotated.yaw.toFixed(1), pitchStr = rotated.pitch.toFixed(1);
      const variants = [
        `camera @s set minecraft:free pos ${x} ${y} ${z} rot ${pitchStr} ${yawStr}`,
        `camera @s set minecraft:free pos ${x} ${y} ${z} rot ${yawStr} ${pitchStr}`,
        `camera @s set minecraft:free position ${x} ${y} ${z} rotation ${yawStr} ${pitchStr}`,
        `camera @s set free pos ${x} ${y} ${z} rot ${yawStr} ${pitchStr}`,
      ];
      for (const cmd of variants) {
        if (applied) break;
        try { player.runCommand(cmd); applied = true; } catch {}
      }
    } catch {}
    return applied;
  }

  resetPlayerCamera(player) {
    try { player.runCommand(`camera @s clear`); } catch {}
    try { player.runCommand(`camera @s fade time 0 0 0`); } catch {}
    try { player.runCommand(`camera @s fov_reset`); } catch {}
    try { player.runCommand(`hud @s reset`); } catch {}
  }

  applyControlOverlay(player, pcPosStr, camPosStr, dimension) {
    try {
      const pid = player.id;
      const camList = this.connections.get(pcPosStr) ?? [];
      if (camList.length === 0) return;

      let camIndex = camList.indexOf(camPosStr);
      if (camIndex < 0) camIndex = 0;
      const camName = `Camera ${camIndex + 1}`;
      const f = new ActionFormData().title(`§r§r§r§C§u §f${camName}`);

      f.button("b:l_");
      f.button("b:c_");
      f.button("b:r_");
      f.label(`t:3_Power left: §l85§r\nUsage: `);

      this.getWorldTimeLabelsAsync(player).then((labels) => {
        try { f.label(`t:l2_§l${labels.clock}`); } catch {}
        try { f.label(`t:2_${labels.period}`); } catch {}
        return f.show(player);
      }).catch(() => {
        try { f.label("t:l2_"); } catch {}
        try { f.label("t:2_"); } catch {}
        return f.show(player);
      }).then((res) => {
        if (!this.viewers.has(pid)) {
          try { player.runCommand(`camera @s clear`); } catch {}
          try { player.runCommand(`camera @s fov_reset`); } catch {}
          try { player.runCommand(`hud @s reset`); } catch {}
          return;
        }

        if (res.canceled || res.selection === undefined) { this.exitView(player); return; }

        const sel = res.selection;
        if (sel === 1) {
          this.exitView(player);
          return;
        }

        const camList = this.connections.get(pcPosStr) ?? [];
        if (camList.length === 0) {
          this.exitView(player);
          return;
        }

        let idx = camList.indexOf(camPosStr);
        if (idx < 0) idx = 0;

        if (camList.length === 1) {
          if (sel === 0 || sel === 2) {
            if (!this.viewers.has(pid)) {
              try { player.runCommand(`camera @s clear`); } catch {}
              try { player.runCommand(`hud @s reset`); } catch {}
              return;
            }

            const step = 10;
            const current = this.viewYaw.get(pid) ?? 0;
            const nextOffset = sel === 0 ? current - step : current + step;
            this.viewYaw.set(pid, nextOffset);
            
            const baseYawValue = this.baseYaw.get(pid);
            if (baseYawValue === undefined) return;
            
            const cam = this.blockFromLocStr(dimension, camPosStr);
            if (!cam || cam.typeId !== "fr:security_cameras") {
              this.exitView(player);
              return;
            }
            
            const camLoc = cam.location;
            const finalYaw = baseYawValue + nextOffset;
            const yawRad = finalYaw * this.DEG_TO_RAD;
            const sinYaw = Math.sin(yawRad);
            const cosYaw = Math.cos(yawRad);
            const offsetDist = 0.4;
            const pos = {
              x: camLoc.x + 0.5 - sinYaw * offsetDist,
              y: camLoc.y + 0.6,
              z: camLoc.z + 0.5 + cosYaw * offsetDist
            };
            
            const ok = this.trySetCamera(player, pos, finalYaw, 0);
            if (!ok) return;
            system.run(() => this.applyControlOverlay(player, pcPosStr, camPosStr, dimension));
          }
          return;
        }

        if (sel === 0) {
          if (!this.viewers.has(pid)) {
            try { player.runCommand(`camera @s clear`); } catch {}
            try { player.runCommand(`hud @s reset`); } catch {}
            return;
          }
          
          const initialRot = this.baseRotations.get(pid);
          if (initialRot !== undefined) {
            try {
              const currentCamBlock = this.blockFromLocStr(dimension, camPosStr);
              if (currentCamBlock && currentCamBlock.typeId === "fr:security_cameras") {
                const currentRot = currentCamBlock.permutation.getState("fr:rotation");
                if (currentRot !== initialRot) {
                  const resetPerm = currentCamBlock.permutation.withState("fr:rotation", initialRot);
                  currentCamBlock.setPermutation(resetPerm);
                }
              }
            } catch {}
          }
          
          const prevIdx = (idx - 1 + camList.length) % camList.length;
          this.viewYaw.set(pid, 0);
          this.autoPan.set(pid, { offset: 0, dir: 1, dwell: 0 });
          this.baseRotations.delete(pid);
          this.baseYaw.delete(pid);
          this.applyView(player, dimension, camList[prevIdx], pcPosStr);
        } else if (sel === 2) {
          if (!this.viewers.has(pid)) {
            try { player.runCommand(`camera @s clear`); } catch {}
            try { player.runCommand(`hud @s reset`); } catch {}
            return;
          }
          
          const initialRot = this.baseRotations.get(pid);
          if (initialRot !== undefined) {
            try {
              const currentCamBlock = this.blockFromLocStr(dimension, camPosStr);
              if (currentCamBlock && currentCamBlock.typeId === "fr:security_cameras") {
                const currentRot = currentCamBlock.permutation.getState("fr:rotation");
                if (currentRot !== initialRot) {
                  const resetPerm = currentCamBlock.permutation.withState("fr:rotation", initialRot);
                  currentCamBlock.setPermutation(resetPerm);
                }
              }
            } catch {}
          }
          
          const nextIdx = (idx + 1) % camList.length;
          this.viewYaw.set(pid, 0);
          this.autoPan.set(pid, { offset: 0, dir: 1, dwell: 0 });
          this.baseRotations.delete(pid);
          this.baseYaw.delete(pid);
          this.applyView(player, dimension, camList[nextIdx], pcPosStr);
        }
      }).catch(() => {
        if (this.viewers.has(pid)) {
          this.exitView(player);
        }
      });
    } catch {}
  }

  manageCameras(player, pcBlock) {
    try {
      const pcPosStr = this.locStr(this.posOf(pcBlock));
      let camList = this.connections.get(pcPosStr) ?? [];
      
      const validCameras = [];
      for (const camPosStr of camList) {
        const camBlock = this.blockFromLocStr(player.dimension, camPosStr);
        if (camBlock && camBlock.typeId === "fr:security_cameras") {
          validCameras.push(camPosStr);
        }
      }
      
      if (validCameras.length !== camList.length) {
        this.connections.set(pcPosStr, validCameras);
        this.saveConnections();
        camList = validCameras;
      }
      
      if (camList.length === 0) {
        player.sendMessage(
          dynamicToast(
            "§l§cNO CAMERAS",
            "§7This PC is not linked to any camera",
            "textures/fr_ui/warning_icon",
            "textures/fr_ui/warning_ui"
          )
        );
        return;
      }

      const form = new ActionFormData().title("Manage cameras").body("§7Select a camera to unlink");
      camList.forEach((posStr) => {
        let status = "§a[FREE]";
        const lockOwner = this.cameraLocks.get(posStr);
        if (lockOwner) {
          const session = this.viewSessions.get(lockOwner);
          const isValidLock = session && session.cam === posStr && this.viewers.has(lockOwner);
          if (!isValidLock) {
            this.cameraLocks.delete(posStr);
          } else {
            status = "§c[IN USE]";
          }
        }
        form.button(`${status} §rCamera (${posStr})`, "textures/ui/trash_default");
      });
      form.label("Test");
      form.show(player).then((res) => {
        if (res.canceled) return;
        const idx = res.selection;
        if (idx === undefined || idx < 0 || idx >= camList.length) return;
        const removed = camList.splice(idx, 1)[0];
        this.connections.set(pcPosStr, camList);
        this.saveConnections();
        player.sendMessage(
          dynamicToast(
            "§l§aUNLINKED",
            `§7Removed camera: §f${removed}`,
            "textures/fr_ui/approve_icon",
            "textures/fr_ui/approve_ui"
          )
        );
      }).catch(() => {});
    } catch {}
  }

  saveConnections() {
    try {
      const arr = Array.from(this.connections.entries());
      world.setDynamicProperty("fr:camera_connections", JSON.stringify(arr));
    } catch (e) {}
  }

  loadConnections() {
    try {
      const raw = world.getDynamicProperty("fr:camera_connections");
      if (!raw) return;
      const arr = JSON.parse(raw);
      this.connections.clear();
      for (const [pc, cams] of arr) {
        if (Array.isArray(cams)) this.connections.set(pc, cams.filter(c => typeof c === 'string'));
        else if (typeof cams === 'string') this.connections.set(pc, [cams]);
      }
    } catch (e) { this.connections.clear(); }
  }
}

const securityCameraSystem = new SecurityCameraSystem();
system.run(() => securityCameraSystem.initialize());

