import { world, system, Player } from "@minecraft/server";

// TPS Monitoring
let tickCounter = 0;
let lastTickCount = 0;
let currentTPS = 20;
let lastTPSUpdate = Date.now();

system.runInterval(() => {
	tickCounter++;
	const now = Date.now();
	const elapsed = now - lastTPSUpdate;
	
	if (elapsed >= 1000) {
		const ticksInSecond = tickCounter - lastTickCount;
		currentTPS = ticksInSecond;
		lastTickCount = tickCounter;
		lastTPSUpdate = now;
	}
}, 1);

function getTPSColor(tps) {
	if (tps >= 19) return "§a"; // Green
	if (tps >= 15) return "§e"; // Yellow
	if (tps >= 10) return "§6"; // Orange
	return "§c"; // Red
}

function getTPSStatus(tps) {
	if (tps >= 19) return "§aEXCELENT";
	if (tps >= 15) return "§eGOOD";
	if (tps >= 10) return "§6SLOW";
	return "§cLAGGING";
}

const lastViewedBlock = new Map();
const ALLOWED_PLAYER = "Y4H1RX 11";

system.runInterval(() => {
	const players = world.getAllPlayers();
	if (players.length === 0) return;
	
	const absoluteTick = system.currentTick;
	
	for (let i = 0; i < players.length; i++) {
		const player = players[i];
		
		// Solo permitir al jugador específico
		if (player.name !== ALLOWED_PLAYER) continue;
		
		try {
			// Verificar tags para determinar qué mostrar
			const showBlocks = player.hasTag("enable_blocks");
			const showTPS = player.hasTag("enable_tps");
			const showTick = player.hasTag("enable_tick");
			const showCoords = player.hasTag("enable_coords");
			
			// Si no tiene ningún tag habilitado, no mostrar nada
			if (!showBlocks && !showTPS && !showTick && !showCoords) {
				const lastKey = lastViewedBlock.get(player.id);
				if (lastKey !== null) {
					player.onScreenDisplay.setActionBar("");
					lastViewedBlock.set(player.id, null);
				}
				continue;
			}
			
			let displayText = "";
			
			// Información de bloque
			if (showBlocks) {
				const { block, face } = player.getBlockFromViewDirection();
				if (block) {
					const blockKey = `${block.location.x},${block.location.y},${block.location.z},${block.typeId}`;
					const lastKey = lastViewedBlock.get(player.id);
					
					if (lastKey !== blockKey) {
						lastViewedBlock.set(player.id, blockKey);
						displayText += `§rblock: §a${block.typeId}§r, face: §7${face}§r, xyz: §7${block.location.x}§r, §7${block.location.y}§r, §7${block.location.z}§r\n`;
						displayText += `data: §e${JSON.stringify(block.permutation.getAllStates(), null, 4)}`;
					} else {
						// Usar cache si es el mismo bloque
						continue;
					}
				} else {
					const lastKey = lastViewedBlock.get(player.id);
					if (lastKey !== null) {
						lastViewedBlock.set(player.id, null);
					}
				}
			}
			
			// Información de coordenadas del jugador
			if (showCoords) {
				const loc = player.location;
				if (displayText) displayText += "\n";
				displayText += `§7Player: §bX:${Math.floor(loc.x)} Y:${Math.floor(loc.y)} Z:${Math.floor(loc.z)}`;
			}
			
			// Información de rendimiento
			let perfInfo = "";
			if (showTPS) {
				const tpsColor = getTPSColor(currentTPS);
				const tpsStatus = getTPSStatus(currentTPS);
				perfInfo += `§7TPS: ${tpsColor}${currentTPS}§7/20 ${tpsStatus}`;
			}
			if (showTick) {
				if (perfInfo) perfInfo += " §8| ";
				perfInfo += `§7Tick: §b${absoluteTick}`;
			}
			if (perfInfo) {
				if (displayText) displayText += "\n";
				displayText += perfInfo;
			}
			
			if (displayText) {
				player.onScreenDisplay.setActionBar(displayText);
			}
		} catch {
			const lastKey = lastViewedBlock.get(player.id);
			if (lastKey !== null) {
				player.onScreenDisplay.setActionBar("");
				lastViewedBlock.set(player.id, null);
			}
		}
	}
}, 10);