import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

const customDayConfig = new Map();
const activeIntervals = new Map();

function convertTicksToTime(ticks) {
  ticks = ticks % 24000;
  let hour24 = Math.floor(ticks / 1000) + 6;
  if (hour24 >= 24) hour24 -= 24;
  let minutes = Math.floor(((ticks % 1000) / 1000) * 60);
  let period = hour24 >= 12 ? "pm" : "am";
  let hour12 = hour24 % 12;
  if (hour12 === 0) hour12 = 12;
  let minuteStr = minutes < 10 ? "0" + minutes : minutes;
  return `${hour12}:${minuteStr} ${period}`;
}

function showRealTimeTitle(player, dimension) {
  try {
    const ticks = world.getTimeOfDay();
    const timeString = convertTicksToTime(ticks);
    const customConfig = customDayConfig.get(player.name);
    const topLine = customConfig 
      ? `${customConfig.format} ${customConfig.day}` 
      : `Day: ${world.getDay()}`;
    dimension.runCommand(`title "${player.name}" title t_slot1`);
  } catch (err) {
  }
}

world.afterEvents.playerInteractWithBlock.subscribe(event => {
  const player = event.player;
  if (!player) return;

  const blockId = event.block?.typeId;

  if (!event.block || blockId !== "fr:switch") {
    return;
  }

  const dimension = world.getDimension("overworld");

  if (player.isSneaking) {
    new ActionFormData()
      .title("Configuración de Hora")
      .body("Elige una opción:")
      .button("Activar hora en tiempo real")
      .button("Configurar día")
      .show(player)
      .then(response => {
        if (response === null) return;
        if (response.selection === 0) {
          const existingInterval = activeIntervals.get(player.name);
          if (existingInterval !== undefined) {
            system.clearRun(existingInterval);
          }
          const intervalId = system.runInterval(() => {
            const currentPlayer = world.getAllPlayers().find(p => p.name === player.name);
            if (!currentPlayer) {
              system.clearRun(intervalId);
              activeIntervals.delete(player.name);
              return;
            }
            showRealTimeTitle(currentPlayer, dimension);
          }, 20);
          activeIntervals.set(player.name, intervalId);
        } else if (response.selection === 1) {
          new ActionFormData()
            .title("Configurar Día")
            .body("Elige una opción:")
            .button("Ver día actual del mundo")
            .button("Establecer día personalizado")
            .show(player)
            .then(resp2 => {
              if (resp2 === null) return;
              if (resp2.selection === 0) {
                const dayNumber = world.getDay();
                customDayConfig.set(player.name, { day: dayNumber, format: "Day:" });
                dimension.runCommand(`title "${player.name}" title t_slot1`);
              } else if (resp2.selection === 1) {
                new ModalFormData()
                  .title("Establecer Día Personalizado")
                  .textField("Set day number:", "Example: 5")
                  .dropdown("Selecciona formato", ["Day:", "Night:"], 0)
                  .show(player)
                  .then(resp3 => {
                    if (resp3 === null) return;
                    const dayInput = resp3.formValues[0];
                    const formatOption = resp3.formValues[1];
                    const format = formatOption === 0 ? "Day:" : "Night:";
                    customDayConfig.set(player.name, { day: dayInput, format: format });
                    dimension.runCommand(`title "${player.name}" title t_slot1`);
                  });
              }
            });
        }
      });
  } else {
    showRealTimeTitle(player, dimension);
  }
});
