import { system, world } from '@minecraft/server'

const TABLE_TYPE_ID = 'fr:party_table';

const updateForBlock = (b) => {
  if (!b || b.typeId !== TABLE_TYPE_ID) return;
  const north = b.north();
  const south = b.south();
  const east = b.east();
  const west = b.west();

  const n = north?.typeId === b.typeId;
  const s = south?.typeId === b.typeId;
  const eConn = east?.typeId === b.typeId;
  const w = west?.typeId === b.typeId;

  b.setPermutation(
    b.permutation
      .withState('fr:north', n)
      .withState('fr:south', s)
      .withState('fr:east', eConn)
      .withState('fr:west', w)
  );
};

const updateNeighborsIfSameType = (block) => {
  if (!block) return;
  const neighbors = [block.north(), block.south(), block.east(), block.west()];
  for (const nb of neighbors) {
    if (nb?.typeId === TABLE_TYPE_ID) updateForBlock(nb);
  }
};

system.beforeEvents.startup.subscribe((eventData) => {
  eventData.blockComponentRegistry.registerCustomComponent('fr:table_connection', {
    onPlace(e) {
      const { block } = e;
      updateForBlock(block);
      updateNeighborsIfSameType(block);
    },
  });
});

world.afterEvents.playerBreakBlock.subscribe(({ block }) => {
  if (!block) return;
  updateNeighborsIfSameType(block);
});